#ifndef OPERATOR_CPP
#define OPERATOR_CPP
#include "Operator.h"
#include <cstddef>
template<class T>
Operator<T>::Operator()
{
    
}

template<class T>
Operator<T>::~Operator()
{
    
}

#endif